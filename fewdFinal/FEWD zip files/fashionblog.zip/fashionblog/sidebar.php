<div id="sidebar">
	<div class="module">
		<h4>About Us</h4>
		<p>Sartre’s List is u salvia, fixie mumblecore ex aesthetic qui minim blog cliche. Retro disrupt keytar PBR, delectus consectetur flexitarian fingerstache selfies nostrud Schlitz. Tempor Wes Anderson banh mi bicycle rights. Eu occaecat Williamsburg yr letterpress, biodiesel plaid tote bag cliche messenger bag lomo bespoke sapiente next level.</p>
		<p class="more"><a href="#">More&hellip;</a></p>
	</div>
	<div class="module ad">
		<img src="http://placehold.it/300x250&text=Ad" alt="ad stuff">
	</div>
	<div class="module">
		<h4>Popular Posts</h4>
		<ul>
			<li><a href="#">10 Things Not to Wear on the Red Carpet</a></li>
			<li><a href="#">Valhalla at The Met Gala</a></li>
			<li><a href="#">Jeans: To Fray or Not to Fray</a></li>
			<li><a href="#">“Trashion” is in This Season</a></li>
			<li><a href="#">Back to School in Pencil Skirts</a></li>
			<li><a href="#">Fall Season Preview</a></li>
			<li><a href="#">Even More Ways to Wrap a Sari!</a></li>
			<li><a href="#">Is Steam Punk Here to Stay?</a></li>
			<li><a href="#">Neighborhoodie Watch</a></li>
			<li><a href="#">Hair Styles of the Damned</a></li>
		</ul>
	</div>
</div>
