<?php get_header(); ?>

<div id="main">
<?php if(have_posts()) : ?>
   <?php while(have_posts()) : the_post(); ?>
        <article>
       		<div class="date"><?php the_time('m.d.Y'); ?></div> <!-- produces 11.12.2014 -->
        	<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        	<!--<img src="http://lorempixel.com/900/300/fashion/7/" alt="fashion stuff">-->
        	<?php the_post_thumbnail('large'); ?>
        	<!-- post thumbnail takes four sizes by default: thumbnail, medium, large, full -->
        	<?php the_content(); ?>
        	<p class="more"><a href="<?php the_permalink(); ?>">Continues...</a></p>
        </article>
   <?php endwhile; ?>
<?php else : ?>
<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>